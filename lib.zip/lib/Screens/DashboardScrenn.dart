import 'package:app_novo_mobile/Screens/GeneralPollsScren.dart';
import 'package:app_novo_mobile/Screens/RankingScreen.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import 'CreatePollScreen.dart';
import 'UserProfileScreen.dart';
import 'DefineWinnerScreen.dart';
import 'VotePollScreen.dart';
import 'MyPollsScreen.dart';
import '../Services/PollProvider.dart';
import '../Services/user_provider.dart';
import 'RankingScreen.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({Key? key}) : super(key: key);

  @override
  _DashboardScreenState createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int _selectedIndex = 0;

  @override
  void initState() {
    super.initState();
    _listenToUserBalance();
  }

  void _listenToUserBalance() {
    final userProvider = context.read<UserProvider>();
    FirebaseFirestore.instance
        .collection('users')
        .doc(userProvider.userId)
        .snapshots()
        .listen((snapshot) {
      if (snapshot.exists) {
        userProvider.updateBalance(snapshot['balance'] ?? 0);
      }
    });
  }

  void _onItemTapped(int index) {
    if (index == 1) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => const UserProfileScreen()),
      );
    } else {
      setState(() {
        _selectedIndex = index;
      });
    }
  }

Future<void> _logout() async {
  bool confirm = await showDialog(
    context: context,
    builder: (context) => AlertDialog(
      title: const Text("Confirmar Logout"),
      content: const Text("Você realmente deseja sair?"),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context, false),
          child: const Text("Cancelar"),
        ),
        TextButton(
          onPressed: () => Navigator.pop(context, true),
          child: const Text("Sair"),
        ),
      ],
    ),
  );

  if (confirm == true) {
    try {
      await FirebaseAuth.instance.signOut();
      Navigator.pushReplacementNamed(context, '/login');
    } catch (e) {
      print("Erro ao deslogar: $e");
    }
  }
}

  @override
  Widget build(BuildContext context) {
    final userProvider = context.watch<UserProvider>();

    return Scaffold(
      appBar: AppBar(
        title: const Text("Dashboard"),
        backgroundColor: Colors.green,
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: _logout,
          ),
        ],
      ),
      body: _selectedIndex == 0
          ? Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: [
                  Text("Saldo do Usuário: ${userProvider.balance} IFCOINS",
                      style: const TextStyle(fontSize: 16)),
                  const SizedBox(height: 20),
                  Expanded(
                    child: StreamBuilder<QuerySnapshot>(
                      stream: FirebaseFirestore.instance
                          .collection('polls')
                          .orderBy('createdAt', descending: true)
                          .snapshots(),
                      builder: (context, snapshot) {
                        if (snapshot.connectionState ==
                            ConnectionState.waiting) {
                          return const Center(
                              child: CircularProgressIndicator());
                        }

                        if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                          return const Center(
                              child: Text("Nenhum bolão criado ainda."));
                        }

                        final polls = snapshot.data!.docs
                            .where((doc) => doc['createdAt'] != null)
                            .toList();
                        final userId = userProvider.userId;

                        final myPolls = polls
                            .where((poll) => poll['creatorId'] == userId)
                            .toList();
                        final otherPolls = polls
                            .where((poll) => poll['creatorId'] != userId)
                            .toList();

                        return ListView(
                          children: [
                            if (myPolls.isNotEmpty) ...[
                              const Padding(
                                padding: EdgeInsets.symmetric(vertical: 8.0),
                                child: Text("Seus Bolões",
                                    style: TextStyle(
                                        fontSize: 18,
                                        fontWeight: FontWeight.bold)),
                              ),
                              ...myPolls
                                  .map((poll) => _buildPollCard(poll, userId))
                                  .toList(),
                            ],
                            const Padding(
                              padding: EdgeInsets.symmetric(vertical: 8.0),
                              child: Text("Bolões Gerais",
                                  style: TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold)),
                            ),
                            ...otherPolls
                                .map((poll) => _buildPollCard(poll, userId))
                                .toList(),
                          ],
                        );
                      },
                    ),
                  ),
                ],
              ),
            )
          : const Center(child: Text("Tela de Ranking")),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.green,
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const RankingScreen()),
          );
        },
        child: const Icon(Icons.add),
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.poll),
            label: 'Bolões',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.account_circle),
            label: 'Perfil',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.star),
            label: 'Ranking',
          ),
        ],
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
      ),
    );
  }

Widget _buildPollCard(QueryDocumentSnapshot poll, String userId) {
  final endDate = DateTime.parse(poll['endDate']);
  final formattedEndDate = DateFormat('dd/MM/yyyy').format(endDate);

  final options = List<String>.from(poll['options']);
  final votes = List<int>.from(poll['votes']);
  final pollData = poll.data() as Map<String, dynamic>?;

  final bets = pollData != null && pollData.containsKey('bets')
      ? List<double>.from((pollData['bets'] as List).map((b) => (b as num).toDouble()))
      : List.filled(options.length, 0.0);

  final odds = pollData != null && pollData.containsKey('odds')
      ? List<double>.from((pollData['odds'] as List).map((o) => (o as num).toDouble()))
      : List.filled(options.length, 1.0);

  List<String> votePercentages = options.map((option) {
    final totalVotes = votes.isEmpty ? 0 : votes.reduce((a, b) => a + b);
    final percentage = totalVotes == 0
        ? 0
        : (votes[options.indexOf(option)] / totalVotes) * 100;
    return '${option}: ${percentage.toStringAsFixed(1)}%';
  }).toList();

  final votedUsersList = poll['votedUsers'] as List<dynamic>? ?? [];
  final betsList = poll['bets'] as List<dynamic>? ?? [];

  // Encontra o índice da aposta do usuário
  final userBetIndex = votedUsersList.indexOf(userId);

  // Obtém o valor apostado pelo usuário
  final userBetAmount = (userBetIndex >= 0 && userBetIndex < betsList.length)
      ? (betsList[userBetIndex] as num).toDouble()
      : 0.0;

  // Obtém o índice da opção apostada pelo usuário
  final userVoteIndex = userBetIndex != -1 ? votes[userBetIndex] : -1;

  // Calcula o retorno potencial
  final potentialReturn = userVoteIndex != -1
      ? userBetAmount * odds[userVoteIndex]
      : 0.0;

  final isCreator = poll['creatorId'] == userId;

  return Card(
    elevation: 4,
    margin: const EdgeInsets.symmetric(vertical: 8),
    child: ListTile(
      title: Text(poll['question']),
      subtitle: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text("Criado por: ${poll['creatorName'] ?? "Desconhecido"}"),
          Text("Data de término: $formattedEndDate"),
          ...votePercentages.map((v) => Text(v)).toList(),
          if (userBetIndex != -1) ...[
            Text("Você apostou: $userBetAmount IFCOINS"),
            Text("Retorno potencial: ${potentialReturn.toStringAsFixed(2)} IFCOINS"),
          ],
          const SizedBox(height: 10),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              if (!isCreator) ...[
                ElevatedButton(
                  onPressed: () async {
                    bool? updated = await Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => VotePollScreen(poll: poll),
                      ),
                    );

                    if (updated == true) {
                      setState(() {});
                    }
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green.shade400,
                  ),
                  child: const Text("Votar no Bolão"),
                ),
              ],
              if (isCreator) ...[
                ElevatedButton(
                  onPressed: () => _defineWinner(context, poll),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.red.shade400,
                  ),
                  child: const Text("Definir Vencedor"),
                ),
              ],
            ],
          ),
        ],
      ),
    ),
  );
}
  double _calculatePotentialReturn(List<double> bets, List<double> odds, int userBetIndex) {
    final userBetAmount = bets[userBetIndex];
    final odd = odds[userBetIndex];
    return userBetAmount * odd;
  }

  Future<void> _defineWinner(BuildContext context, QueryDocumentSnapshot poll) async {
  final currentUserId = FirebaseAuth.instance.currentUser?.uid;
  final creatorId = poll['creatorId'];

  if (currentUserId != creatorId) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
          content:
              Text("Somente o criador do bolão pode definir o vencedor.")),
    );
    return;
  }

  final winnerIndex = await Navigator.push(
    context,
    MaterialPageRoute(
      builder: (context) => DefineWinnerScreen(poll: poll),
    ),
  );

  if (winnerIndex != null) {
    // Remover o bolão após definir o vencedor
    await FirebaseFirestore.instance.collection('polls').doc(poll.id).delete();
  }
  }
}