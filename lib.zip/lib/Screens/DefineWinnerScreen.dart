import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class DefineWinnerScreen extends StatelessWidget {
  final QueryDocumentSnapshot poll;

  const DefineWinnerScreen({Key? key, required this.poll}) : super(key: key);

  /// Método para processar o resultado do jogo e atualizar os saldos dos usuários
  Future<void> processarResultado(String idJogo, String vencedor) async {
    try {
      final DocumentSnapshot jogoSnapshot =
          await FirebaseFirestore.instance.collection('polls').doc(idJogo).get();

      if (!jogoSnapshot.exists) {
        print("Jogo não encontrado!");
        return;
      }

      final Map<String, dynamic>? jogoData =
          jogoSnapshot.data() as Map<String, dynamic>?;

      if (jogoData == null || !jogoData.containsKey('votedUsers')) {
        print("Dados do jogo inválidos!");
        return;
      }

      final List<String> votedUsers = List<String>.from(jogoData['votedUsers'] ?? []);
      final List<int> votes = List<int>.from(jogoData['votes'] ?? []);
      final List<double> bets = List<double>.from(jogoData['bets'] ?? []);
      final List<double> odds = List<double>.from(jogoData['odds'] ?? []);
      final List<String> options = List<String>.from(jogoData['options'] ?? []);

      for (var i = 0; i < votedUsers.length; i++) {
        String idUsuario = votedUsers[i];
        int apostaFeita = votes[i];
        double valorApostado = bets[i];
        double oddApostada = odds[apostaFeita];

        if (options[apostaFeita] == vencedor) {
          double retorno = valorApostado * oddApostada;

          await FirebaseFirestore.instance.collection('users').doc(idUsuario).update({
            'balance': FieldValue.increment(retorno)
          });

          print("Saldo atualizado para o usuário $idUsuario: +$retorno moedas.");
        }
      }

      print("Processamento de apostas concluído para o jogo $idJogo.");
    } catch (e) {
      print("Erro ao processar resultado: $e");
    }
  }

  Future<void> _defineWinner(BuildContext context, int winnerIndex) async {
    final currentUserId = FirebaseAuth.instance.currentUser?.uid;
    final creatorId = poll['creatorId'];

    // Verifica se o usuário atual é o criador do bolão
    if (currentUserId != creatorId) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text("Somente o criador do bolão pode definir o vencedor.")),
      );
      return;
    }

    try {
      // Obtém os dados do bolão
      final pollData = poll.data() as Map<String, dynamic>?;

      if (pollData == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Erro ao carregar dados do bolão.")),
        );
        return;
      }

      final options = List<String>.from(pollData['options'] ?? []);

      // Verifica se o índice do vencedor é válido
      if (winnerIndex < 0 || winnerIndex >= options.length) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Opção vencedora inválida.")),
        );
        return;
      }

      // Chama o método para processar o resultado
      await processarResultado(poll.id, options[winnerIndex]);

      // Exclui o bolão após definir o vencedor
      await FirebaseFirestore.instance.collection('polls').doc(poll.id).delete();

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
            content:
                Text("Vencedor definido como '${options[winnerIndex]}'. Bolão excluído.")),
      );
      Navigator.pop(context); // Volta para a tela anterior
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Ocorreu um erro ao definir o vencedor: $e")),
      );
    }
  }

  Future<double> _getUserBalance() async {
    final userId = FirebaseAuth.instance.currentUser?.uid;

    if (userId != null) {
      try {
        final userDoc = await FirebaseFirestore.instance
            .collection('users')
            .doc(userId)
            .get();

        if (userDoc.exists) {
          // Retorna o saldo como double
          return userDoc['balance'] ?? 0.0;
        } else {
          return 0.0; // Caso o usuário não exista no Firestore
        }
      } catch (e) {
        print("Erro ao carregar saldo do usuário: $e");
        return 0.0;
      }
    }
    return 0.0; // Caso não tenha um usuário autenticado
  }

  @override
  Widget build(BuildContext context) {
    final options = List<String>.from(poll['options'] ?? []);

    return Scaffold(
      appBar: AppBar(
        title: const Text("Definir Vencedor"),
        backgroundColor: Colors.red,
      ),
      body: FutureBuilder<double>(
        future: _getUserBalance(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return Center(child: Text('Erro ao carregar saldo'));
          }

          final userBalance = snapshot.data ?? 0.0;

          return ListView(
            children: [
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Text(
                  'Saldo Atual: $userBalance moedas',
                  style: const TextStyle(
                      fontSize: 18, fontWeight: FontWeight.bold),
                ),
              ),
              for (var i = 0; i < options.length; i++)
                ListTile(
                  title: Text(options[i]),
                  trailing: ElevatedButton(
                    onPressed: () async {
                      // Mostra um indicador de carregamento
                      showDialog(
                        context: context,
                        barrierDismissible: false,
                        builder: (context) =>
                            const Center(child: CircularProgressIndicator()),
                      );

                      try {
                        // Define o vencedor
                        await _defineWinner(context, i);
                      } catch (e) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text("Erro ao definir vencedor: $e")),
                        );
                      } finally {
                        // Fecha o indicador de carregamento
                        Navigator.pop(context);
                      }
                    },
                    child: const Text("Selecionar"),
                  ),
                ),
            ],
          );
        },
      ),
    );
  }
}